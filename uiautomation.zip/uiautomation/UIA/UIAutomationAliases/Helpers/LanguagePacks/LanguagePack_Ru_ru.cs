﻿/*
 * Created by SharpDevelop.
 * User: Alexander Petrovskiy
 * Date: 10/18/2012
 * Time: 4:54 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

namespace UIAutomationAliases
{
    using System;
    
    /// <summary>
    /// Description of LanguagePack_Ru_ru.
    /// </summary>
    public class LanguagePack_Ru_ru : LanguagePack
    {
        public LanguagePack_Ru_ru()
        {
        }
        
        public string Button { get {return @"Кнопку";} }
        public string Calendar { get {return @"Календарь";} }
        public string Custom { get {return @"Прочий";} }
        public string Edit { get {return @"ПолеВвода";} }
    }
}
