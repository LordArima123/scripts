﻿/*
 * Created by SharpDevelop.
 * User: Alexander Petrovskiy
 * Date: 08.12.2011
 * Time: 10:33
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using MbUnit.Framework;//using MbUnit.Framework; // using MbUnit.Framework;

namespace UIAutomationTest
{
    /// <summary>
    /// Description of StartUp.
    /// </summary>
    public class StartUp
    {
        public StartUp()
        {
        }
        
        //[Suite]
        public void SuiteSetUp()
        {
            // System.Diagnostics.Process.Start(
            // @"..\..\..\TestUIAutomation\bin\Debug\TestUIAutomation.exe");
        }
    }
}
