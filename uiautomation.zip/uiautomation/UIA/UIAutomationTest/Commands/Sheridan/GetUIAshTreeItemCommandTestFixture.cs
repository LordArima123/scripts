﻿/*
 * Created by SharpDevelop.
 * User: Alexander Petrovskiy
 * Date: 10/22/2012
 * Time: 5:43 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace UIAutomationTest.Commands.Sheridan
{
    /// <summary>
    /// Description of GetUIAshTreeItemCommandTestFixture.
    /// </summary>
    public class GetUIAshTreeItemCommandTestFixture
    {
        public GetUIAshTreeItemCommandTestFixture()
        {
        }
    }
}
