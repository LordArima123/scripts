﻿/*
 * Created by SharpDevelop.
 * User: Alexander Petrovskiy
 * Date: 11/1/2012
 * Time: 6:10 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

namespace UIAutomationTest.Commands.ExecutionPlan
{
	using System;
	
	/// <summary>
	/// Description of ShowUIAExecutionPlanCommandTestFixture.
	/// </summary>
	public class ShowUIAExecutionPlanCommandTestFixture
	{
		public ShowUIAExecutionPlanCommandTestFixture()
		{
		}
	}
}
