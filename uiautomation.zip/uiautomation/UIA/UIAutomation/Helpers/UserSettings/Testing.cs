﻿/*
 * Created by SharpDevelop.
 * User: Alexander Petrovskiy
 * Date: 2/20/2012
 * Time: 11:05 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

namespace UIAutomation
{
    using System;
    
    /// <summary>
    /// Description of Testing.
    /// </summary>
    public static class Testing
    {
        static Testing()
        {
        }
        
//  //public static System.Collections.Generic.List<TestResult >  TestSuites { get; internal set; }
//  //internal static System.Collections.Generic.List<TestResult >  TestScenarios { get; internal set; }
//  //public static System.Collections.Generic.List<TestResult >  TestResults { get; internal set; }
// 
// 
// public static System.Collections.Generic.List<TestSuite >  TestResults { get; internal set; }
// 
// internal static void AddTestResult(string previousTestResultLabel,
// bool passed)
// {
//  //initTestResults();
//  //TestResults[TestResults.Count - 1].Label =
//  // previousTestResultLabel;
//  //TestResults[TestResults.Count - 1].Passed = 
//  // passed;
//  ////TestResults.Add(new TestResult());
// }
// 
// internal static void AddTestResultDetail(object detail)
// {
//  ////initTestResults();
//  ////TestResults[CurrentData.TestResults.Count - 1].Details.Add(detail);
// }
// 
// internal static void AddTestSuite(string testSuiteName)
// {
//  //TestResults
// }
// 
// internal static void AddTestScenario(string testScenarioName)
// {
//  //TestScenarios
// }
// }
// 
// public class TestResult
// {
// public TestResult()
// {
// this.Details = 
// new System.Collections.ArrayList();
// }
// 
// public string Label { get; internal set; }
// public System.Collections.ArrayList Details { get; internal set; }
// public bool Passed { get; internal set; }
// }
// 
// public class TestScenario
// {
// public TestScenario()
// {
//  //this.Details = 
//  // new System.Collections.ArrayList();
// TestResults.Add(new TestResult());
// }
// 
// public string Name { get; internal set; }
// public System.Collections.Generic.List<TestResult >  TestResults {get; internal set; }
//  //public System.Collections.ArrayList Details { get; internal set; }
//  //public bool Passed { get; internal set; }
// }
// 
// public class TestSuite : System.Collections.Generic.List<TestScenario > 
// {
// public TestSuite()
// {
//  //this.Details = 
//  // new System.Collections.ArrayList();
// TestScenarios.Add(new TestScenario());
// }
// 
// public string Name { get; internal set; }
// public System.Collections.Generic.List<TestScenario >  TestScenarios {get; internal set; }
//  //public System.Collections.ArrayList Details { get; internal set; }
//  //public bool Passed { get; internal set; }
    }
}
