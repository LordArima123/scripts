﻿/*
 * Created by SharpDevelop.
 * User: Alexander Petrovskiy
 * Date: 2/22/2013
 * Time: 9:50 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace UIAutomation.Helpers.UnderlyingCode.Commands.Container
{
    /// <summary>
    /// Description of UIANewContainerCommand.
    /// </summary>
    public class UIANewContainerCommand
    {
        public UIANewContainerCommand()
        {
        }
    }
}
