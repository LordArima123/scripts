﻿/*
 * Created by SharpDevelop.
 * User: Alexander Petrovskiy
 * Date: 3/21/2013
 * Time: 10:10 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

public enum WizardStepActions
{
    //NotSet,
    Forward,
    Backward,
    Cancel,
    Stop
}