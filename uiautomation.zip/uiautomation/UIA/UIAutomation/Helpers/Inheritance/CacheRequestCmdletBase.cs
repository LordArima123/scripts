﻿/*
 * Created by SharpDevelop.
 * User: Alexander Petrovskiy
 * Date: 5/12/2012
 * Time: 12:07 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

namespace UIAutomation
{
    using System;
    using System.Windows.Automation;
    
    /// <summary>
    /// Description of CacheRequestCmdletBase.
    /// </summary>
    public class CacheRequestCmdletBase : HasScriptBlockCmdletBase
    {
        public CacheRequestCmdletBase()
        {
        }
    }
}
