﻿/*
 * Created by SharpDevelop.
 * User: Alexander Petrovskiy
 * Date: 2/22/2013
 * Time: 9:49 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace UIAutomation.Commands.Container
{
    /// <summary>
    /// Description of NewUIAContainerCommand.
    /// </summary>
    public class NewUIAContainerCommand
    {
        public NewUIAContainerCommand()
        {
        }
    }
}
