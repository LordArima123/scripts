﻿/*
 * Created by SharpDevelop.
 * User: Alexander Petrovskiy
 * Date: 2/19/2013
 * Time: 10:50 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

namespace UIAutomation.Commands
{
    using System;
    using System.Management.Automation;
    
    /// <summary>
    /// Description of StartUIARemoteDesktopSessionCommand.
    /// </summary>
    [Cmdlet(VerbsLifecycle.Start, "UIARemoteDesktopSession")]
    public class StartUIARemoteDesktopSessionCommand
    {
        public StartUIARemoteDesktopSessionCommand()
        {
        }
    }
}
