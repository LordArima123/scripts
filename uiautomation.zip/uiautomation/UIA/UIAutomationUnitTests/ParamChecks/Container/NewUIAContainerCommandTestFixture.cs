﻿/*
 * Created by SharpDevelop.
 * User: Alexander Petrovskiy
 * Date: 2/22/2013
 * Time: 9:51 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace UIAutomationUnitTests.ParamChecks.Container
{
    /// <summary>
    /// Description of NewUIAContainerCommandTestFixture.
    /// </summary>
    public class NewUIAContainerCommandTestFixture
    {
        public NewUIAContainerCommandTestFixture()
        {
        }
    }
}
