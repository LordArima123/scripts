﻿/*
 * Created by SharpDevelop.
 * User: Alexander Petrovskiy
 * Date: 5/29/2013
 * Time: 1:31 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace UIAutomationUnitTests.ParamChecks.No
{
    /// <summary>
    /// Description of WaitUIANoWindowCommandTestFixture.
    /// </summary>
    public class WaitUIANoWindowCommandTestFixture
    {
        public WaitUIANoWindowCommandTestFixture()
        {
        }
    }
}
