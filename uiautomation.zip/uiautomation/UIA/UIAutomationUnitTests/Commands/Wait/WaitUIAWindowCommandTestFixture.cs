﻿/*
 * Created by SharpDevelop.
 * User: Alexander Petrovskiy
 * Date: 2/25/2013
 * Time: 1:36 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace UIAutomationUnitTests.Commands.Get
{
    /// <summary>
    /// Description of WaitUIAWindowCommandTestFixture.
    /// </summary>
    public class WaitUIAWindowCommandTestFixture
    {
        public WaitUIAWindowCommandTestFixture()
        {
        }
    }
}
