﻿/*
 * Created by SharpDevelop.
 * User: Alexander Petrovskiy
 * Date: 6/5/2013
 * Time: 2:32 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace UIAutomationUnitTests.Commands.Common
{
    /// <summary>
    /// Description of HideUIACurrentHighlighterCommandTestFixture.
    /// </summary>
    public class HideUIACurrentHighlighterCommandTestFixture
    {
        public HideUIACurrentHighlighterCommandTestFixture()
        {
        }
    }
}
