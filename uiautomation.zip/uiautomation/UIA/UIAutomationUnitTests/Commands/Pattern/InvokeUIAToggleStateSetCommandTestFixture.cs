﻿/*
 * Created by SharpDevelop.
 * User: Alexander Petrovskiy
 * Date: 2/22/2013
 * Time: 7:09 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace UIAutomationUnitTests.Commands.Pattern
{
    /// <summary>
    /// Description of InvokeUIAToggleStateSetCommandTestFixture.
    /// </summary>
    public class InvokeUIAToggleStateSetCommandTestFixture
    {
        public InvokeUIAToggleStateSetCommandTestFixture()
        {
        }
    }
}
