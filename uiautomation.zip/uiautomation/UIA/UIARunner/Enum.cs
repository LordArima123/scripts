﻿/*
 * Created by SharpDevelop.
 * User: Alexander Petrovskiy
 * Date: 6/29/2012
 * Time: 4:35 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

namespace UIARunner
{
    using System;
    
    public enum RunModes
    {
        GUI = 1,
        Unattended = 2
    }
}
