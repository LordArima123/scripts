﻿///*
// * Created by SharpDevelop.
// * User: Alexander Petrovskiy
// * Date: 11/20/2012
// * Time: 10:26 PM
// * 
// * To change this template use Tools | Options | Coding | Edit Standard Headers.
// */
//
//namespace PSTestLib
//{
//    using System;
//    using System.Management.Automation;
//    
//    /// <summary>
//    /// Description of PSTestLibCommand.
//    /// </summary>
//    public class PSTestLibCommand
//    {
//        public PSTestLibCommand()
//        {
//        }
//    }
//    
//    using System;
//    using System.Management.Automation;
//    
//    /// <summary>
//    /// Description of TLSrvCommand.
//    /// </summary>
//    internal abstract class TLSrvCommand
//    {
//        internal TLSrvCommand() //TLSCmdletBase cmdlet)
//        {
//        }
//        
//        internal TLSCmdletBase Cmdlet { get; set; }
//        internal abstract void Execute();
//    }
//}
