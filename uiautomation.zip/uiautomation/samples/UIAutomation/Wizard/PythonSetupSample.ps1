﻿Invoke-WebRequest http://python.org/ftp/python/3.3.0/python-3.3.0.msi
# or
Invoke-WebRequest http://python.org/ftp/python/3.3.0/python-3.3.0.amd64.msi

