#Get-UIADesktop | Get-UIAButton -Name 'Show desktop' | Move-UIACursor -x 5 -y 20;
#Get-UIADesktop | Get-UIAButton -Name 'Start' | Invoke-UIAButtonClick;
Start-UIAMetroStartScreen