#Invoke-UIAHotKey -Win -Key z
Show-UIAMetroMenu