#Invoke-UIAHotKey -Win -Key c
Show-UIAMetroCharm