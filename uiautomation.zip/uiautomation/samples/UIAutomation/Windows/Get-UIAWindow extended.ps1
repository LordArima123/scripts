ipmo C:\Projects\PS\STUPS\UIA\UIAutomation\bin\Release35\UIAutomation.dll
Get-UIAWindow -Name *power* -Verbose
Get-UIAWindow -Class console* -Verbose

