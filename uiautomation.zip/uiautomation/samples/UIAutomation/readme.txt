1. Edit start.ps1
Set paths to the modules
2. Run start.ps1
It sets paths to the modules
3. Run examples, they'll be using paths from the global variables the start.ps1 script sets