#& .\testTMXwithAutoGeneration_3.ps1
C:\Projects\PS\STUPS\samples\samples\TMX\testTMXwithAutoGeneration_3.ps1
& C:\Projects\PS\STUPS\samples\samples\TMX\testTMXwithAutoGeneration_3.ps1